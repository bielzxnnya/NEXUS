package com.nexus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

private val Ink = Color(0xFF101522)
private val Panel = Color(0xFF1A2333)
private val Accent = Color(0xFF63E6BE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

data class Task(val title: String, val done: Boolean = false)

@Composable
fun NexusApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nexus", 0) }
    var tasks by remember {
        mutableStateOf(run {
            val arr = runCatching { JSONArray(prefs.getString("tasks", "[]")) }.getOrDefault(JSONArray())
            List(arr.length()) { i -> val o = arr.getJSONObject(i); Task(o.getString("title"), o.getBoolean("done")) }
        })
    }
    var note by remember { mutableStateOf(prefs.getString("note", "") ?: "") }
    var newTask by remember { mutableStateOf("") }
    fun saveTasks(list: List<Task>) {
        tasks = list
        val arr = JSONArray()
        list.forEach { t -> arr.put(org.json.JSONObject().put("title", t.title).put("done", t.done)) }
        prefs.edit().putString("tasks", arr.toString()).apply()
    }
    val completed = tasks.count { it.done }
    val progress = if (tasks.isEmpty()) 0f else completed.toFloat() / tasks.size

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Ink, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Ink).padding(20.dp)) {
            Text("NEXUS", color = Accent, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("SEU ESPAÇO. SUAS IDEIAS.", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(22.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("Seu progresso", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Accent, trackColor = Color(0xFF354052))
                    Spacer(Modifier.height(8.dp))
                    Text("$completed de ${tasks.size} tarefas concluídas", color = Color.LightGray, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("MINHAS TAREFAS", color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 13.dp)) {
                    if (newTask.isEmpty()) Text("Adicionar uma tarefa...", color = Color.Gray)
                    BasicTextField(value = newTask, onValueChange = { newTask = it }, singleLine = true, textStyle = LocalTextStyle.current.copy(color = Color.White))
                }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { if (newTask.isNotBlank()) { saveTasks(tasks + Task(newTask.trim())); newTask = "" } }, colors = ButtonDefaults.buttonColors(containerColor = Accent), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp)) { Text("ADD", color = Ink, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(tasks) { index, task ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.done, onCheckedChange = { checked -> saveTasks(tasks.toMutableList().also { it[index] = task.copy(done = checked) }) }, colors = CheckboxDefaults.colors(checkedColor = Accent))
                        Text(task.title, Modifier.weight(1f), color = if (task.done) Color.Gray else Color.White, fontSize = 14.sp)
                        TextButton(onClick = { saveTasks(tasks.filterIndexed { i, _ -> i != index }) }) { Text("×", color = Color(0xFFFF8A8A), fontSize = 20.sp) }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("ANOTAÇÕES", color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(112.dp).background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
                if (note.isEmpty()) Text("Escreva uma ideia ou lembrete...", color = Color.Gray)
                BasicTextField(value = note, onValueChange = { note = it; prefs.edit().putString("note", it).apply() }, modifier = Modifier.fillMaxSize(), textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp))
            }
            Spacer(Modifier.height(8.dp))
            Text("NEXUS • versão 1.0", Modifier.align(Alignment.CenterHorizontally), color = Color.Gray, fontSize = 10.sp)
        }
    }
}
